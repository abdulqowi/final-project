<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\user_details;
use Faker\Generator as Faker;

$factory->define(user_details::class, function (Faker $faker) {
    return [
        //
    ];
});
