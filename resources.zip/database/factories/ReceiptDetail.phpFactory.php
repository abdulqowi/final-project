<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ReceiptDetail.php;
use Faker\Generator as Faker;

$factory->define(ReceiptDetail.php::class, function (Faker $faker) {
    return [
        //
    ];
});
